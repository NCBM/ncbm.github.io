#!/bin/bash

echo Date: `date`
cd ~/.xom/
echo Cloning...
git clone https://github.com/anonymous5l/ncmdump.git
cd ncmdump
echo Start installing...
make
cp -f ncmdump $PREFIX/bin/
rm -rf ~/.xom/ncmdump
echo Done.
exit

