#!/bin/bash
# Super .init.rc
# by Tekin-Miz(WorldMoZara)

abin=$PREFIX/bin
if test -e ~/.init.rc
then
    update=1
fi
cp -f $1/res/.init.rc ~/
if [ $update -eq 1 ]
then
    exit 0
fi
if test -e $abin/bash
then
    echo -e "\nsource ~/.init.rc" >> ~/.bashrc
fi
if test -e $abin/zsh
then
    echo -e "\nsource ~/.init.rc" >> ~/.zshrc
fi
if test -e $abin/fish
then
    mkdir -p $PREFIX/etc/fish
    echo -e "\nsource ~/.init.rc" >> $PREFIX/etc/fish/config.fish
fi
