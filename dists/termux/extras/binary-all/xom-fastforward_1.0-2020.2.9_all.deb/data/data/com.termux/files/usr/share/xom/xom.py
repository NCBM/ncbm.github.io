#!/bin/python
import os
import sys

import urwid

force_reboot = 0
# path detecting
spa = sys.path[0]
if os.path.isdir(spa):
    selfpath = spa
else:
    selfpath = os.path.dirname(sys.path[0])

xom_home = os.environ['HOME'] + '/.xom'
if os.path.exists(xom_home) == False:
    os.mkdir(xom_home)

apiver = os.popen('echo -n $(getprop ro.build.version.sdk)').read()

def utext(text):
    return urwid.Text(text)

def menu_button(caption, callback):
    button = urwid.Button(caption)
    urwid.connect_signal(button, 'click', callback)
    return urwid.AttrMap(button, None, focus_map='reversed')

def sub_menu(caption, choices):
    contents = menu(caption, choices)
    def open_menu(button):
        return top.open_box(contents, 7)
    return menu_button([caption, u'...'], open_menu)

def menu(title, choices):
    body = [urwid.Text(title), urwid.Divider()]
    body.extend(choices)
    return urwid.ListBox(urwid.SimpleFocusListWalker(body))

def item_chosen(button):
    if button.label == '超级initrc':
        os.system('bash ' + selfpath + '/res/initrc.sh ' + selfpath)
        complete(button.label, u'新建会话以生效！\n或输入 source .init.rc 在当前会话中立即生效。')
    elif button.label == '安装termux-ohmyzsh':
        os.system('pkg in curl;cd ~;sh -c "$(curl -fsSL https://github.com/Cabbagec/termux-ohmyzsh/raw/master/install.sh)";cd $OLDPWD')
        complete(button.label, u'')
    elif button.label == '美化vim(spacevim)':
        # WIP
        pass
    elif button.label == '获取内部储存权限':
        os.system('termux-setup-storage')
        complete(button.label, u'')
    elif button.label == '修复termux新版的一排键盘':
        os.system("mkdir ~/.termux;echo \"extra-keys = [['ESC','/','-','HOME','UP','END','PGUP'],['TAB','CTRL','ALT','LEFT','DOWN','RIGHT','PGDN']]\" >> /data/data/com.termux/files/home/.termux/termux.properties")
        response = urwid.Text([u'配置完成！\n请重启 Termux 以使配置生效！', u'\n'])
        done = menu_button(u'OK', reboot_term)
        top.open_box(urwid.Filler(urwid.Pile([response, done])), 6)
    elif button.label == '安装基本工具':
        os.system('apt install tar unzip python git wget curl vim-python nano -y')
        os.system('pip install -i https://pypi.tuna.tsinghua.edu.cn/simple pip -U && pip config set global.index-url https://pypi.tuna.tsinghua.edu.cn/simple')
        complete(button.label, u'')
    elif button.label == '安装 BaiduPCS-Go':
        os.system('echo "deb [trusted=yes] http://termux.iikira.com stable main" >> /data/data/com.termux/files/usr/etc/apt/sources.list.d/iikira.list;pkg install baidupcs-go -y >/dev/null 2>&1;BaiduPCS-Go config set -appid 266719')
        complete(button.label, u'退出后输入 BaiduPCS-Go 启动程序')
    elif button.label == '配置 Xfce 桌面环境':
        os.system('bash ' + selfpath + '/res/termux-xfce-installer.sh')
        complete(button.label, u'退出后输入 startvnc 以启动')
    elif button.label == 'you-get':
        os.system('pip install you-get')
        complete(button.label, u'退出后输入 you-get <链接> 以下载文件')
    elif button.label == 'jupyter':
        os.system('apt install clang libzmq -y && pip install jupyter')
        complete(button.label, u'')
    elif button.label == 'numpy':
        os.system('pip install numpy')
        complete(button.label, u'')
    elif button.label == 'lxml':
        os.system('pkg install sshpass libxml2 libxslt openssl libffi openssl-tool libzmq freetype pkg-config scrypt libcrypt ccrypt libgcrypt libpng libiconv ndk-sysroot libjpeg-turbo -y && pip install wheel lxml')
    elif button.label == '纯文本浏览器':
        os.system('pkg in -y elinks')
        response = urwid.Text([u'退出why-and-xom后执行 elinks http://www.baidu.com后打开百度。'])
        done = menu_button(u'OK', closewin)
        top.open_box(urwid.Filler(urwid.Pile([response, done])), 6)
        complete(button.label, u'')
    elif button.label == '关于':
        contr = open(selfpath + '/res/contributors.txt')
        response = urwid.Text([u'关于\n\n', contr.read()])
        done = menu_button(u'OK', closewin)
        top.open_box(urwid.Filler(urwid.Pile([response, done])), 10)
        contr.close()
    elif button.label == '帮助':
        helpmsg = open(selfpath + '/res/help.txt')
        response = urwid.Text([helpmsg.read()])
        done = menu_button(u'OK', closewin)
        top.open_box(urwid.Filler(urwid.Pile([response, done])), 6)
        helpmsg.close()
    elif button.label == 'test':
        sysver = os.popen('echo -n $(getprop ro.build.version.release)').read()
        pyver = os.popen('python -V').read()
        una = os.uname()
        vimver = os.popen('vim --version | grep IMproved').read()
        response = urwid.Text([
            "Android ",sysver," (API ",apiver,")\n",
            pyver,
            "内核：",una.sysname,' ',una.release,
            "\n内核版本：",una.version,
            "\n主机名：",una.nodename,
            "\n架构：",una.machine,'\n',
            vimver
            ])
        done = menu_button(u'OK', closewin)
        top.open_box(urwid.Filler(urwid.Pile([response, done])), 6)
    elif button.label == '编译并安装 adb 和 fastboot':
        response = urwid.Text([button.label, u"\n\n即将编译程序…… \n这可能需要几分钟的时间，同时你的设备可能会有发热。\n你可以查看 $HOME/.xom/adb-complie.log 获取详细信息。\n是否开始？"])
        begin = menu_button(u'开始', adb_complie)
        cancel = menu_button(u'取消', closewin)
        top.open_box(urwid.Filler(urwid.Pile([response, begin, cancel])), 4)
    else:
        # 未知功能
        response = urwid.Text([u'未知的功能：', button.label, u'！\n'])
        done = menu_button(u'OK', closewin)
        top.open_box(urwid.Filler(urwid.Pile([response, done])), 6)

def complete(label, text):
    response = urwid.Text([label, u'\n\n', u'操作已完成！\n' + text + u'\n'])
    done = menu_button(u'OK', closewin)
    top.open_box(urwid.Filler(urwid.Pile([response, done])), 6)

def closewin(button):
    top.original_widget = top.original_widget[0]
    top.box_level -= 1

def adb_complie(arg1):
    os.system('bash ' + selfpath + '/res/adb-termux.sh > $HOME/.xom/adb-complie.log 2>&1')
    closewin(None)
    completed = urwid.Text([u"安装完成！\n退出程序后执行 adb 或 fastboot 以执行操作。\n"])
    done = menu_button(u'OK', closewin)
    top.open_box(urwid.Filler(urwid.Pile([completed, done])), 4)

def deb_tsinghua(button):
    api = eval(apiver)
    if api >= 24:
        os.system("sed -i 's@^\(deb.*stable main\)$@#\1\ndeb https://mirrors.tuna.tsinghua.edu.cn/termux stable main@' $PREFIX/etc/apt/sources.list")
        complete(button.label, u"退出 why-and-xom 后执行 apt update 以使配置生效。\n若出现问题请参阅 https://mirrors.tuna.tsinghua.edu.cn/help/termux/ 上提供的解决办法（Android P 系统尤其注意）。")
    else:
        resp = urwid.Text([u'操作失败\n\n', u'未满足需求：API_VERSION(ro.build.version.sdk)==', apiver, u'<24\n'])
        done = menu_button(u'确认', closewin)
        top.open_box(urwid.Filler(urwid.Pile([resp, done])), 6)

def pre_ncmd(button):
    resp = urwid.Text([button.label, '\n\n原项目地址：https://github.com/anonymous5l/ncmdump\n', u"即将编译程序……\n这可能需要一小会的时间。\n你可以查看 $HOME/.xom/ncmdump-complie.log 获取详细信息。\n是否开始？\n"])
    begin = menu_button(u'开始', ncmd_complie)
    cancel = menu_button(u'取消', closewin)
    top.open_box(urwid.Filler(urwid.Pile([resp, begin, cancel])), 4)

def ncmd_complie(arg1):
    os.system('bash ' + selfpath + '/res/ncmdump.sh > $HOME/.xom/ncmdump-complie.log 2>&1')
    closewin(None)
    resp = urwid.Text([u"安装完成！\n退出程序后执行 ncmdump 进行操作。\n原项目地址：https://github.com/anonymous5l/ncmdump\n"])
    done = menu_button(u'确认', closewin)
    top.open_box(urwid.Filler(urwid.Pile([resp, done])), 5)

def reboot_term(button):
    exit_program(button)
    if force_reboot == 1:
        os.system('pkill com.termux')

def exit_program(button):
    raise urwid.ExitMainLoop()

menu_top = menu(u' Why + Xom', [
        sub_menu(u'Termux工具', [
            menu_button(u'超级initrc', item_chosen),
            menu_button(u'获取内部储存权限', item_chosen),
            menu_button(u'更换清华源', deb_tsinghua),
            menu_button(u'安装termux-ohmyzsh', item_chosen),
            menu_button(u'修复termux新版的一排键盘', item_chosen),
            menu_button(u'美化vim(spacevim)',item_chosen),
            menu_button(u'安装 BaiduPCS-Go', item_chosen),
            menu_button(u'安装基本工具', item_chosen),
            menu_button(u'test', item_chosen),
            menu_button(u'编译并安装 adb 和 fastboot', item_chosen),
            menu_button(u'安装 ncmdump（本地编译）', pre_ncmd),
            menu_button(u'配置 Xfce 桌面环境', item_chosen),
            menu_button(u'纯文本浏览器',item_chosen),
            sub_menu(u'安装 Python 工具', [
                menu_button(u'you-get', item_chosen),
                menu_button(u'jupyter', item_chosen),
                menu_button(u'numpy', item_chosen),
                menu_button(u'lxml', item_chosen),
                ]),
        ]),
        menu_button(u'帮助', item_chosen),
        menu_button(u'关于', item_chosen),
        menu_button(u'退出',exit_program),
])

class CascadingBoxes(urwid.WidgetPlaceholder):
    max_box_levels = 4

    def __init__(self, box):
        super(CascadingBoxes, self).__init__(urwid.SolidFill(u' '))
        self.box_level = 0
        self.open_box(box, 7)

    def open_box(self, box, h):
        self.original_widget = urwid.Overlay(urwid.AttrMap(urwid.LineBox(box), 'win'),
            self.original_widget,
            align='center', width=('relative', 80),
            valign='middle', height=('relative', h * 10),
            min_width=24, min_height=8,
            left=self.box_level * 3,
            right=(self.max_box_levels - self.box_level - 1) * 3,
            top=self.box_level * 2,
            bottom=(self.max_box_levels - self.box_level - 1) * 2)
        self.box_level += 1

    def keypress(self, size, key):
        if (key == 'esc' or key == 'left') and self.box_level > 1:
            self.original_widget = self.original_widget[0]
            self.box_level -= 1
        elif key == '#':
            palette = [('default', 'default', 'default'),]
            urwid.MainLoop(ConversationListBox(), palette).run()
            exit_program(None)
        else:
            # print(key)
            return super(CascadingBoxes, self).keypress(size, key)

def interactive_text():
    return utext([u'如果你不小心来到了这里，请不要担心。\n', u'欢迎来到 why-and-xom 交互式界面！\n', u'输入 "help" 查看命令列表。\nWhy-and-Xom 1.0 [Interactive]\n'])

def question():
    return urwid.Pile([urwid.Edit(('default', u"-> "))])

def answer(cmd):
    name = cmd.split(' ')
    if name[0] == 'help':
        i_help_f = open(selfpath + '/res/i_help.txt')
        i_help = i_help_f.read()
        i_help_f.close()
        return utext(i_help)
    elif name[0] == 'exit':
        exit_program(None)
    elif name[0] == 'self':
        return utext(selfpath)
    elif name[0] == 'home':
        return utext(xom_home)
    elif name[0] == 'func':
        pass
    elif name[0] == 'exec':
        if len(name) < 2:
            return utext(u"exec：未知类型\n")
        elif name[1] == 'shell':
            if len(name) < 3:
                return utext(u'exec：未输入命令')
            os.system('echo; ' + ' '.join(name[2:]))
            return utext("\n")
        elif name[1] == 'python':
            os.system('echo; python')
            return utext('\n')
        else:
            return utext(u"exec：未知类型：" + name[1] + "\n")
    elif name[0] == 'pack':
        if len(name) < 2:
            return utext(u"pack：未知操作\n")
        elif name[1] == 'up':
            os.system('echo; cd ' + selfpath + '; pyinstaller -F --add-data res:res xom.py')
            return utext(u'\n操作完成')
        elif name[1] == 'deb':
            return utext(u'\nW.I.P')
        else:
            return utext(u"pack：未知操作：" + name[1] + "\n")
    return utext(('default', u"未知命令：" + name[0] + "\n"))

class ConversationListBox(urwid.ListBox):
    def __init__(self):
        body = urwid.SimpleFocusListWalker([interactive_text(), question()])
        super(ConversationListBox, self).__init__(body)

    def keypress(self, size, key):
        key = super(ConversationListBox, self).keypress(size, key)
        if key == 'ctrl d':
            exit_program(None)
        if key != 'enter':
            return key
        name = self.focus[0].edit_text
        # replace or add response
        self.focus.contents[1:] = [(answer(name), self.focus.options())]
        pos = self.focus_position
        # add a new question
        self.body.insert(pos + 1, question())
        self.focus_position = pos + 1

urwid.set_encoding("UTF-8")
top = CascadingBoxes(menu_top)
urwid.MainLoop(top, palette=[('reversed', 'standout', ''), ('title', 'black', 'light gray'), ('win', 'black', 'light gray')]).run()

