#!/bin/python
import os
import sys
from re import match

import urwid

force_reboot = 0

# 确保无论是否被打包都能正确调用资源文件
spa = sys.path[0] # 获取解释器脚本目录
if os.path.isdir(spa): # 判断对象是否是目录
    selfpath = spa
else:
    selfpath = os.path.dirname(sys.path[0])

usr_home = os.getenv('HOME')
usr_prefix = sys.prefix # 获取PREFIX
termux_pa = usr_home + '/.termux'
xom_home = usr_home + '/.xom'
if not os.path.exists(xom_home): # 创建xom_home
    os.mkdir(xom_home)
if not os.path.exists(termux_pa):
    os.mkdir(termux_pa)

apiver = os.popen('echo -n $(getprop ro.build.version.sdk)').read() # 获取api等级

def utext(text): # 没人想写死老长的**玩意
    return urwid.Text(text)

def menu_button(caption, callback):
    button = urwid.Button(caption)
    urwid.connect_signal(button, 'click', callback)
    return urwid.AttrMap(button, None, focus_map='reversed')

def sub_menu(caption, choices):
    contents = menu(caption, choices)
    def open_menu(button):
        return top.open_box(contents, 7)
    return menu_button([caption, u'...'], open_menu)

def menu(title, choices):
    body = [utext(title), urwid.Divider()]
    body.extend(choices)
    return urwid.ListBox(urwid.SimpleFocusListWalker(body))

def item_chosen(button):
    if button.label == '超级initrc':
        os.system('bash ' + selfpath + '/res/initrc.sh ' + selfpath)
        complete(button.label, u'新建会话以生效！\n或输入 source .init.rc 在当前会话中立即生效。')
    elif button.label == '安装termux-ohmyzsh':
        os.system('pkg in curl;cd ~;sh -c "$(curl -fsSL https://github.com/Cabbagec/termux-ohmyzsh/raw/master/install.sh)";cd $OLDPWD')
        complete(button.label, u'')
    elif button.label == '美化vim(spacevim)':
        # WIP
        pass
    elif button.label == '获取内部储存权限':
        os.system('termux-setup-storage')
        complete(button.label, u'')
    elif button.label == '修复termux新版的一排键盘':
        fpa = termux_pa + '/termux.properties'
        prop = open(fpa, 'a')
        if prop.writable():
            prop.write("\nextra-keys = [['ESC','/','-','HOME','UP','END','PGUP'],['TAB','CTRL','ALT','LEFT','DOWN','RIGHT','PGDN']]\n")
            success = True
        else:
            success = False
        prop.close()
        if success:
            response = utext([u'配置完成！\n请重启 Termux 以使配置生效！', u'\n'])
            done = menu_button(u'OK', reboot_term)
            top.open_box(urwid.Filler(urwid.Pile([response, done])), 6)
        else:
            file_fail(fpa)
    elif button.label == '安装基本工具':
        os.system('apt install tar unzip python git wget curl vim-python nano -y')
        os.system('pip install -i https://pypi.tuna.tsinghua.edu.cn/simple pip -U && pip config set global.index-url https://pypi.tuna.tsinghua.edu.cn/simple')
        complete(button.label, u'')
    elif button.label == '配置 Xfce 桌面环境':
        if apicheck(24):
            os.system('bash ' + selfpath + '/res/termux-xfce-installer.sh')
            complete(button.label, u'退出后输入 startvnc 以启动')
        else:
            api_fail(24)
    elif button.label == 'you-get':
        os.system('pip install you-get')
        complete(button.label, u'退出后输入 you-get <链接> 以下载文件')
    elif button.label == 'jupyter':
        os.system('apt install clang libzmq -y && pip install jupyter')
        complete(button.label, u'')
    elif button.label == 'numpy':
        os.system('pip install numpy')
        complete(button.label, u'')
    elif button.label == 'lxml':
        os.system('pkg install sshpass libxml2 libxslt openssl libffi openssl-tool libzmq freetype pkg-config scrypt libcrypt ccrypt libgcrypt libpng libiconv ndk-sysroot libjpeg-turbo -y && pip install wheel lxml')
    elif button.label == '纯文本浏览器':
        os.system('pkg in -y elinks')
        response = urwid.Text([u'退出why-and-xom后执行 elinks http://www.baidu.com后打开百度。'])
        done = menu_button(u'OK', closewin)
        top.open_box(urwid.Filler(urwid.Pile([response, done])), 6)
        complete(button.label, u'')
    elif button.label == '关于':
        contr = open(selfpath + '/res/contributors.txt')
        response = urwid.Text([u'关于\n\n', contr.read()])
        done = menu_button(u'OK', closewin)
        top.open_box(urwid.Filler(urwid.Pile([response, done])), 10)
        contr.close()
    elif button.label == '帮助':
        helpmsg = open(selfpath + '/res/help.txt')
        response = urwid.Text([helpmsg.read()])
        done = menu_button(u'OK', closewin)
        top.open_box(urwid.Filler(urwid.Pile([response, done])), 6)
        helpmsg.close()
    elif button.label == '版本测试':
        sysver = os.popen('echo -n $(getprop ro.build.version.release)').read()
        pyver = os.popen('python -V').read()
        una = os.uname()
        vimver = os.popen('vim --version | grep IMproved').read()
        response = urwid.Text([
            "Android ",sysver," (API ",apiver,")\n",
            pyver,
            "内核：",una.sysname,' ',una.release,
            "\n内核版本：",una.version,
            "\n主机名：",una.nodename,
            "\n架构：",una.machine,'\n',
            vimver
            ])
        done = menu_button(u'OK', closewin)
        top.open_box(urwid.Filler(urwid.Pile([response, done])), 6)
    elif button.label == 'adb 和 fastboot（本地编译）':
        response = utext([button.label, u"\n\n项目地址：https://git.coding.net/ArcTrue-WDMZR/adb-termux.git\n即将编译程序……\n这可能需要几分钟的时间，同时你的设备可能会有发热。\n你可以查看 $HOME/.xom/adb-complie.log 获取详细信息。\n是否开始？"])
        begin = menu_button(u'开始', adb_complie)
        cancel = menu_button(u'取消', closewin)
        uninstall = menu_button(u'卸载', adb_unins)
        top.open_box(urwid.Filler(urwid.Pile([response, begin, cancel, uninstall])), 5)
    else:
        # 未知功能
        resp = utext([u'未知功能：', button.label, u'！\n'])
        done = menu_button(u'OK', closewin)
        top.open_box(urwid.Filler(urwid.Pile([resp, done])), 6)

def complete(label, text):
    resp = utext([label, u'\n\n', u'操作已完成！\n' + text + u'\n'])
    done = menu_button(u'OK', closewin)
    top.open_box(urwid.Filler(urwid.Pile([resp, done])), 6)

def file_fail(filename):
    resp = utext([filename, u'：操作文件失败\n', '请检查文件是否存在且用户拥有足够权限！'])
    done = menu_button(u'OK', closewin)
    top.open_box(urwid.Filler(urwid.Pile([resp, done])), 4)

def apicheck(api_version):
    api = eval(apiver)
    if api_version <= api:
        return True
    return False

def api_fail(requirement):
    resp = utext([u'操作失败\n\n', u'未满足需求：API_VERSION(ro.build.version.sdk)==', apiver, u' < ', requirement, '\n'])
    done = menu_button(u'确认', closewin)
    top.open_box(urwid.Filler(urwid.Pile([resp, done])), 5)

def closewin(button):
    top.original_widget = top.original_widget[0]
    top.box_level -= 1

def adb_complie(arg1):
    os.system('pkg in make automake libtool -y')
    os.system('bash ' + selfpath + '/res/adb-termux.sh > $HOME/.xom/adb-complie.log 2>&1')
    closewin(None)
    completed = utext([u"安装完成！\n退出程序后执行 adb 或 fastboot 以执行操作。\n"])
    done = menu_button(u'OK', closewin)
    top.open_box(urwid.Filler(urwid.Pile([completed, done])), 4)

def adb_unins(arg1):
    fpa = (usr_prefix + '/bin/adb', usr_prefix + '/bin/fastboot')
    for f_pa in fpa:
        if os.path.exists(f_pa):
            os.remove(f_pa)
        else:
            file_fail(f_pa)

def deb_tsinghua(button):
    if apicheck(24):
        os.system("sed -i 's@^\(deb.*stable main\)$@#\1\ndeb https://mirrors.tuna.tsinghua.edu.cn/termux stable main@' $PREFIX/etc/apt/sources.list")
        complete(button.label, u"退出 why-and-xom 后执行 apt update 以使配置生效。\n若出现问题请参阅 https://mirrors.tuna.tsinghua.edu.cn/help/termux/ 上提供的解决办法（Android P 系统尤其注意）。")
    else:
        api_fail(24)

def pre_ncmd(button):
    resp = utext([button.label, '\n\n原项目地址：https://github.com/anonymous5l/ncmdump\n', u"即将编译程序……\n这可能需要一小会的时间。\n你可以查看 $HOME/.xom/ncmdump-complie.log 获取详细信息。\n是否开始？\n"])
    begin = menu_button(u'开始', ncmd_complie)
    cancel = menu_button(u'取消', closewin)
    uninstall = menu_button(u'卸载', ncmd_unins)
    top.open_box(urwid.Filler(urwid.Pile([resp, begin, cancel, uninstall])), 5)

def ncmd_complie(arg1):
    os.system('bash ' + selfpath + '/res/ncmdump.sh > $HOME/.xom/ncmdump-complie.log 2>&1')
    closewin(None)
    resp = utext([u"安装完成！\n退出程序后执行 ncmdump 进行操作。\n原项目地址：https://github.com/anonymous5l/ncmdump\n"])
    done = menu_button(u'确认', closewin)
    top.open_box(urwid.Filler(urwid.Pile([resp, done])), 5)

def ncmd_unins(arg1):
    fpa = usr_prefix + '/bin/ncmdump'
    if os.path.exists(fpa):
        os.remove(fpa)
    else:
        file_fail(fpa)

def reboot_term(button):
    exit_program(button)
    if force_reboot == 1:
        os.system('pkill com.termux')

def exit_program(button):
    raise urwid.ExitMainLoop()

menu_top = menu(u' Why + Xom', [
        sub_menu(u'Termux工具', [
            sub_menu(u'环境配置', [
                menu_button(u'获取内部储存权限', item_chosen),
                menu_button(u'更换清华源', deb_tsinghua),
                menu_button(u'安装基本工具', item_chosen),
                menu_button(u'配置 Xfce 桌面环境', item_chosen),
                ]),
            sub_menu(u'界面美化', [
                menu_button(u'安装termux-ohmyzsh', item_chosen),
                menu_button(u'修复termux新版的一排键盘', item_chosen),
                menu_button(u'美化vim(spacevim)',item_chosen),
                menu_button(u'超级initrc', item_chosen),
                ]),
            sub_menu(u'安装程序', [
                #BaiduPCS-GO已停止维护，无法使用
                menu_button(u'adb 和 fastboot（本地编译）', item_chosen),
                menu_button(u'ncmdump（本地编译）', pre_ncmd),
                menu_button(u'纯文本浏览器',item_chosen),
                sub_menu(u'Python 工具', [
                    menu_button(u'you-get', item_chosen),
                    menu_button(u'jupyter', item_chosen),
                    menu_button(u'numpy', item_chosen),
                    menu_button(u'lxml', item_chosen),
                    ]),
                ]),
            menu_button(u'版本测试', item_chosen),
        ]),
        menu_button(u'帮助', item_chosen),
        menu_button(u'关于', item_chosen),
        menu_button(u'退出',exit_program),
])

class CascadingBoxes(urwid.WidgetPlaceholder):
    max_box_levels = 4

    def __init__(self, box):
        super(CascadingBoxes, self).__init__(urwid.SolidFill(u' '))
        self.box_level = 0
        self.open_box(box, 7)

    def open_box(self, box, h):
        self.original_widget = urwid.Overlay(urwid.AttrMap(urwid.LineBox(box), 'win'),
            self.original_widget,
            align='center', width=('relative', 80),
            valign='middle', height=('relative', h * 10),
            min_width=24, min_height=8,
            left=self.box_level * 3,
            right=(self.max_box_levels - self.box_level - 1) * 3,
            top=self.box_level * 2,
            bottom=(self.max_box_levels - self.box_level - 1) * 2)
        self.box_level += 1

    def keypress(self, size, key):
        if (key == 'esc' or key == 'left') and self.box_level > 1:
            self.original_widget = self.original_widget[0]
            self.box_level -= 1
        elif key == '#':
            palette = [('default', 'default', 'default'),]
            urwid.MainLoop(ConversationListBox(), palette).run()
            exit_program(None)
        elif key == 'ctrl d':
            exit_program(None)
        else:
            # print(key)
            return super(CascadingBoxes, self).keypress(size, key)

def interactive_text():
    return utext([u'如果你不小心来到了这里，请不要担心。\n', u'欢迎来到 why-and-xom 交互式界面！\n', u'输入 "help" 查看命令列表。\nWhy-and-Xom 1.1 [Interactive]\n'])

def question():
    return urwid.Pile([urwid.Edit(('default', u"-> "))])

def answer(cmd):
    name = cmd.split(' ')
    if name[0] == 'help':
        i_help_f = open(selfpath + '/res/i_help.txt')
        i_help = i_help_f.read()
        i_help_f.close()
        return utext(i_help)
    elif name[0] == 'exit':
        exit_program(None)
    elif name[0] == 'self':
        return utext(selfpath)
    elif name[0] == 'home':
        return utext(xom_home)
    elif name[0] == 'func':
        if len(name) < 2:
            return utext(u"func：未知类型\n")
        elif name[1] == 'list':
            fobj = open(selfpath + '/res/funclist.txt')
            comp = fobj.readlines()
            fobj.close()
            return utext(comp)
        elif name[1] == '__brainpower__':
            return utext('O-oooooooooo AAAAE-A-A-I-A-U- JO-oooooooooooo AAE-O-A-A-U-U-A- E-eee-ee-eee AAAAE-A-E-I-E-A- JO-ooo-oo-oo-oo EEEEO-A-AAA-AAAA')
        else:
            return utext(u"func：未知操作：" + name[1] + "\n")
    elif name[0] == 'exec':
        if len(name) < 2:
            return utext(u"exec：未知类型\n")
        elif name[1] == 'shell':
            if len(name) < 3:
                return utext(u'exec：未输入命令')
            os.system('echo; ' + ' '.join(name[2:]))
            return utext("\n")
        elif name[1] == 'python':
            os.system('echo; python')
            return utext('\n')
        else:
            return utext(u"exec：未知类型：" + name[1] + "\n")
    elif name[0] == 'pack':
        if len(name) < 2:
            return utext(u"pack：未知操作\n")
        elif name[1] == 'up':
            if os.path.exists(selfpath + '/base_library.zip'):
                return utext(u'程序不允许被多次打包！')
            os.system('echo; cd ' + selfpath + '; pyinstaller -F --add-data res:res xom.py')
            return utext(u'\n操作完成')
        elif name[1] == 'deb':
            execfile_path = os.path.join(selfpath, 'dist', 'xom')
            if not os.path.exists(execfile_path):
                return utext(u'\n不存在 xom 程序或程序已被打包！')
            elif len(name) < 4:
                return utext(u'用法：pack deb <版本（不含日期）> <架构>')
            packver = name[2]
            arch = name[3]
            version = packver + '-' + os.popen('echo -n `date +"%Y.%-m.%d"`').read()
            packname = 'xom_' + version + '_' + arch
            xom_pack_deb = os.path.join(xom_home, packname)
            control_path = xom_pack_deb + '/DEBIAN'
            if not os.path.exists(xom_pack_deb):
                os.mkdir(xom_pack_deb)
            if not os.path.exists(control_path):
                os.mkdir(control_path)
            packpath = os.path.join(xom_pack_deb, 'data/data/com.termux/files', 'usr', 'bin')
            mkdirR(packpath)
            # 复制二进制文件到.xom
            os.replace(execfile_path, packpath + '/xom')
            # 程序逐行写入信息到 DEBIAN/control
            control_file = open(control_path + '/control', 'w')
            control_file.write('Package: xom\n')
            control_file.write('Version: ' + version + '\n')
            control_file.write('Architecture: ' + arch + '\n')
            control_file.write('Maintainer: pyg2007@pyg2007, Tekin-Miz@worldmozara\n')
            size_i = os.popen('echo -n `du -sk ' + packpath + '/xom`').read()
            size_f = match(r'(\d)+', size_i)[0]
            control_file.write('Installed-Size: ' + str(size_f) + ' kb\n')
            control_file.write('Depends: git, sed, curl, grep, clang, make\n')
            control_file.write('Description: Termux 工具箱，集成了 why 和 xom\n')
            control_file.write('Homepage: http://xomandwhy.tk\n')
            control_file.close()
            os.system('chmod 644 ' + control_path + '/control')
            os.system('chmod 755 ' + control_path)
            # DPKG打包
            os.system('cd '+ xom_home + ';dpkg-deb -b ' + packname)
            os.system('rm -rf ' + xom_pack_deb)
            return utext([u'打包成功！\n', u'文件位于 ', xom_home])
        elif name[1] == 'clean':
            ls = str(os.listdir())
            if ls.__contains__('build'):
                removeR(selfpath + '/build')
            if ls.__contains__('dist'):
                removeR(selfpath + '/dist')
            if ls.__contains__('__pycache__'):
                removeR(selfpath + '/__pycache__')
            if ls.__contains__('xom.spec'):
                os.remove(selfpath + '/xom.spec')
            return utext(u'清理完成！')
        else:
            return utext(u"pack：未知操作：" + name[1] + "\n")
    return utext(('default', u"未知命令：" + name[0] + "\n"))

def mkdirR(path):
    if os.path.exists(path):
        return
    parent = os.path.split(path)[0]
    if os.path.exists(parent):
        os.mkdir(path)
    else:
        mkdirR(parent)
        mkdirR(path)

def removeR(path):
    ls = os.listdir(path)
    for ob in ls:
        pa = os.path.join(path, ob)
        if os.path.isdir(pa):
            removeR(pa)
        else:
            os.remove(pa)
    os.removedirs(path)

class ConversationListBox(urwid.ListBox):
    def __init__(self):
        body = urwid.SimpleFocusListWalker([interactive_text(), question()])
        super(ConversationListBox, self).__init__(body)

    def keypress(self, size, key):
        key = super(ConversationListBox, self).keypress(size, key)
        if key == 'ctrl d':
            exit_program(None)
        if key != 'enter':
            return key
        name = self.focus[0].edit_text
        # replace or add response
        self.focus.contents[1:] = [(answer(name), self.focus.options())]
        pos = self.focus_position
        # add a new question
        self.body.insert(pos + 1, question())
        self.focus_position = pos + 1

urwid.set_encoding("UTF-8")
top = CascadingBoxes(menu_top)
if __name__ == '__main__': # 防止有傻缺直接 import xom 被吓到
    urwid.MainLoop(top, palette=[('reversed', 'standout', ''), ('title', 'black', 'light gray'), ('win', 'black', 'light gray')]).run()

