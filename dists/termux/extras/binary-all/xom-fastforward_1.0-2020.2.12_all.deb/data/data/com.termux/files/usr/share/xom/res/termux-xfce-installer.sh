#!/bin/bash
# termux-xfce
# by 萌系生物研究员（From 酷安(coolapk)）

clrreset="\033[0m"
clrwarn="\033[33m"

installed=`pm list packages com.realvnc.viewer.android`
if test -z $installed
then
    echo -e ${clrwarn}"[WARNING] Cannot find a VNC viewer!"$clrreset
fi
pkg i -y x11-repo
pkg i -y xfce tigervnc openbox aterm
echo -e "#\!/bin/bash -e\nam start com.realvnc.viewer.android/com.realvnc.viewer.android.app.ConnectionChooserActivity\nexport DISPLAY=:1\nXvnc -geometry 1280x720 --SecurityTypes=None \$DISPLAY&\nsleep 1s\nopenbox-session&\nthunar&\nstartxfce4" > $PREFIX/bin/startvnc
chmod +x $PREFIX/bin/startvnc
echo "[INFO] Complete!"
echo "[INFO] Use 'startvnc' to open remote desktop."
exit 0
